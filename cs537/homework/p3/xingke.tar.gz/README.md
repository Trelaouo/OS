Name: Xingke
Email: xsun326@wisc.edu
Wisc ID: 9083691957
CS login: xingke
status: finish all except pipe
